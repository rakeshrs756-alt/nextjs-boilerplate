# सोलोट्रॉनिक - हिंदी डेमो वेबसाइट

यह एक पूर्ण हिंदी डेमो साइट है जो rooftop solar सेवाओं के लिए तैयार की गई है।

## क्या शामिल है
- `index.html` — मुख्य पृष्ठ (पूर्ण हिंदी सामग्री)
- `style.css` — स्टाइल शीट
- `script.js` — छोटा जावास्क्रिप्ट (फॉर्म हैंडलिंग)
- `README.md`, `GUIDE.md`, `VISIBILITY.md`, `LICENSE`, `.gitignore`

## त्वरित शुरुआत
1. GitHub पर नया रिपॉजिटरी बनाएं: `solotronic-hindi-site`
2. रिपॉजिटरी को **Public** चुनें और बनाएं।
3. इस पैकेज की सारी फाइलें अपलोड कर के Commit करें।
4. (Optional) Settings → Pages से GitHub Pages सक्रिय करें।

