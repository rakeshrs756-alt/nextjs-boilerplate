# उपयोगकर्ता मार्गदर्शिका (हिंदी)


## GitHub (वेब UI) से अपलोड करना — सरल तरीका

1. GitHub पर लॉगिन करके **New repository** पर जाएँ: https://github.com/new
2. Repository name: `solotronic-hindi-site`
3. Description: `सोलोट्रॉनिक एनर्जी — हिंदी डेमो`
4. Visibility: **Public** चुनें
5. Create repository पर क्लिक करें
6. Repository पेज पर **Add file → Upload files** चुनें
7. ZIP से सारी फाइलें ड्रैग‑एंड‑ड्रॉप करें और **Commit changes** करें

### Git CLI (यदि आप चाहें)
```bash
git init
git add .
git commit -m "Initial Hindi demo site"
git branch -M main
git remote add origin https://github.com/<your-username>/solotronic-hindi-site.git
git push -u origin main
```

## GitHub Pages से पब्लिश करना
- Settings → Pages → Deploy from a branch → Branch: `main` → Folder: `/root` → Save
- आपका साइट URL: `https://<your-username>.github.io/solotronic-hindi-site/`

