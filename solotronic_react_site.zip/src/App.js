
import React from "react";
import { motion } from "framer-motion";
import { Phone, Zap, Home, Shield } from "lucide-react";

function App() {
  return (
    <div className="min-h-screen bg-gray-50 text-gray-900">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-green-600 to-yellow-500 text-white py-20 px-6 text-center">
        <motion.h1
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-4xl md:text-5xl font-bold mb-4"
        >
          Rooftop Solar Lagao, Bijli Bill Ghatao ⚡
        </motion.h1>
        <p className="text-lg md:text-xl mb-6">
          Govt Subsidy + Free Installation + Zero Tension EMI Plans
        </p>
        <button className="px-6 py-3 bg-white text-green-700 font-semibold rounded-2xl shadow-lg">
          📞 Free Consultation Book Karein
        </button>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 px-6 grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-6xl mx-auto">
        {[
          { icon: <Zap className="h-10 w-10 text-green-600" />, title: "Govt Approved Subsidy" },
          { icon: <Home className="h-10 w-10 text-green-600" />, title: "Free Installation" },
          { icon: <Shield className="h-10 w-10 text-green-600" />, title: "0% EMI Options" },
          { icon: <Phone className="h-10 w-10 text-green-600" />, title: "24/7 Support" },
        ].map((item, idx) => (
          <div key={idx} className="rounded-2xl shadow-md bg-white p-6 flex flex-col items-center text-center">
            {item.icon}
            <h3 className="mt-4 font-semibold text-lg">{item.title}</h3>
          </div>
        ))}
      </section>

      {/* Contact Form */}
      <section className="bg-white py-16 px-6">
        <div className="max-w-2xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Contact Us</h2>
          <form className="grid gap-4">
            <input type="text" placeholder="Full Name" className="p-3 border rounded-xl" />
            <input type="text" placeholder="Phone Number" className="p-3 border rounded-xl" />
            <input type="text" placeholder="Address" className="p-3 border rounded-xl" />
            <textarea placeholder="Message" className="p-3 border rounded-xl" rows={4}></textarea>
            <button type="submit" className="bg-green-600 text-white rounded-2xl py-3">
              Submit
            </button>
          </form>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-gray-300 text-center py-6">
        <p>© {new Date().getFullYear()} Solotronic Energy Pvt Ltd | Call: 7000255282</p>
      </footer>
    </div>
  );
}

export default App;
