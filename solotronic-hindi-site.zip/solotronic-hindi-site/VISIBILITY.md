# Private → Public (सुरक्षित तरीके से)

1. सुनिश्चित करें कि कोड में कोई **API key, पासवर्ड, या निजी फाइल** न हो।
2. Git history में संवेदनशील जानकारी नहीं हो (यदि हो तो `git filter-repo` या `git rebase` का उपयोग करें)।
3. GitHub Repo → Settings → Danger Zone → Change repository visibility → Public → पुष्टि के लिए repo नाम लिखें → Change visibility।
