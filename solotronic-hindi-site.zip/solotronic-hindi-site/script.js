
function handleSubmit(e){e.preventDefault();alert('धन्यवाद! हमारी टीम जल्द ही आपसे संपर्क करेगी।');}
document.getElementById('year').textContent=new Date().getFullYear();
